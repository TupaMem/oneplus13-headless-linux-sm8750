#!/system/bin/sh
# ==============================================================================
# customize.sh — Module Installation Script (KernelSU / APatch / Magisk)
# Target: OnePlus 13 (dodge / Snapdragon 8 Elite SM8750)
# ==============================================================================
SKIPUNZIP=0

ui_print "========================================================"
ui_print "  OnePlus 13 (SM8750) DualBoot Linux & Safe OTA Manager "
ui_print "  KernelSU-Next • APatch • Magisk v26+ (Action + WebUI) "
ui_print "========================================================"

SOC="$(getprop ro.board.platform)"
DEVICE="$(getprop ro.product.device)"
SLOT="$(getprop ro.boot.slot_suffix)"

ui_print "[*] Detected Platform : ${SOC:-sun} (${DEVICE:-dodge})"
ui_print "[*] Current Boot Slot : ${SLOT:-_a}"

# Create persistent Linux container & backup directories on /data
mkdir -p /data/media/0/linux/.slot_b_backup
touch /data/media/0/linux/.nomedia

# Set executable permissions on module scripts and binaries
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm_recursive "$MODPATH/system/bin" 0 0 0755 0755
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
set_perm "$MODPATH/action.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755

ui_print "[+] Installed CLI utilities into /system/bin:"
ui_print "    - op13-updater-engine (Root Backend & Safe OTA/Linux Installer)"
ui_print "    - op13-slot-guardian  (Automatic Slot A/B Protection Daemon)"
ui_print "    - boot-linux          (1-Command Switch & Reboot to Slot B Linux)"
ui_print "[+] Installed KernelSU/APatch WebUI + Magisk Action TUI."
ui_print "========================================================"
