#!/system/bin/sh
# ==============================================================================
# action.sh — Interactive Volume-Key Hardware Menu (Magisk Action / KernelSU)
# Triggered directly when the user taps the "Action" button on the module card!
# ==============================================================================
MODDIR=${0%/*}
ENGINE="${MODDIR}/system/bin/op13-updater-engine"
GUARD="${MODDIR}/system/bin/op13-slot-guardian"

echo "========================================================"
echo "  OP13 DualBoot Linux & Safe OTA Manager — Action Menu  "
echo "========================================================"
"$ENGINE" status
echo "--------------------------------------------------------"
echo "Выберите действие клавишами громкости (Volume Up / Down):"
echo "  [Громкость + (Up)]   : Переключить слот и перезагрузить в Slot B (Linux)"
echo "  [Громкость - (Down)] : Перейти к следующим опциям (Safe OTA / Установка Linux)"
echo "--------------------------------------------------------"

# Helper to read a single Volume Key press (timeout 10s -> defaults to status/protection)
read_vol_key() {
    if command -v getevent >/dev/null 2>&1; then
        EV="$(timeout 10 getevent -qlc 1 2>/dev/null | grep -E "KEY_VOLUMEUP|KEY_VOLUMEDOWN" || true)"
        if echo "$EV" | grep -q "KEY_VOLUMEUP"; then
            echo "UP"
            return 0
        elif echo "$EV" | grep -q "KEY_VOLUMEDOWN"; then
            echo "DOWN"
            return 0
        fi
    fi
    echo "TIMEOUT"
}

KEY1="$(read_vol_key)"
if [ "$KEY1" = "UP" ]; then
    echo "[*] Переключение активного слота на Slot B (_b) и перезагрузка в Linux..."
    "$ENGINE" switch-slot b --reboot
    exit 0
fi

echo "--------------------------------------------------------"
echo "Опция 2:"
echo "  [Громкость + (Up)]   : Безопасная прошивка OTA/ZIP из /sdcard/Download/ota.zip"
echo "  [Громкость - (Down)] : Установить Linux в Slot B (32GB) / Обновить защиту"
echo "--------------------------------------------------------"

KEY2="$(read_vol_key)"
if [ "$KEY2" = "UP" ]; then
    OTA_CANDIDATE="$(ls -t /sdcard/Download/*.zip 2>/dev/null | head -n 1 || true)"
    if [ -n "$OTA_CANDIDATE" ]; then
        echo "[*] Найден пакет обновления: $OTA_CANDIDATE"
        "$ENGINE" flash-ota-safe "$OTA_CANDIDATE"
    else
        echo "[!] В /sdcard/Download/ не найдено .zip файлов."
    fi
    exit 0
else
    if [ ! -f /data/media/0/linux/rootfs.img ]; then
        echo "[*] Контейнер rootfs.img не найден. Запуск установки Linux (32 ГБ)..."
        "$ENGINE" install-linux 32
    else
        echo "[*] Запуск полной проверки, снапшота и RO-блокировки Slot B..."
        "$GUARD" auto
    fi
    echo "[+] Также доступен полный графический интерфейс:"
    echo "    - Вкладка WebUI в KernelSU / APatch / MMRL"
    echo "    - Или в браузере: http://127.0.0.1:8750"
fi
