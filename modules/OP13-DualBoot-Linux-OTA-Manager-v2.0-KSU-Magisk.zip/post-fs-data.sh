#!/system/bin/sh
# ==============================================================================
# post-fs-data.sh — Early Boot Slot B Hardware Write-Lock
# Runs before Zygote/update_engine starts; immediately locks boot_b, init_boot_b,
# and vendor_boot_b read-only at the block layer.
# ==============================================================================
MODDIR=${0%/*}

for part in boot_b init_boot_b vendor_boot_b; do
    for path in "/dev/block/by-name/${part}" "/dev/block/bootdevice/by-name/${part}"; do
        if [ -b "$path" ]; then
            blockdev --setro "$path" 2>/dev/null || true
        fi
    done
done
