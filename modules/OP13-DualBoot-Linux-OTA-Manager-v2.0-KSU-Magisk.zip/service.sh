#!/system/bin/sh
# ==============================================================================
# service.sh — Late-Start Boot Guardian & Local WebUI Bridge
# ==============================================================================
MODDIR=${0%/*}

# Wait until Android boot completes
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done

# 1. Run automatic Slot Guardian (marks Slot A successful, disables update_engine,
#    verifies Slot B SHA-256 hashes, auto-restores if overwritten, and locks RO)
"${MODDIR}/system/bin/op13-slot-guardian" auto

# 2. Start lightweight local HTTP WebUI server on 127.0.0.1:8750 via BusyBox httpd
#    so users on standard Magisk (without built-in KSU WebUI) can also open
#    http://127.0.0.1:8750 in any browser!
for bb in /data/adb/ksu/bin/busybox /data/adb/ap/bin/busybox /data/adb/magisk/busybox /system/bin/busybox; do
    if [ -x "$bb" ]; then
        "$bb" httpd -p 127.0.0.1:8750 -h "${MODDIR}/webroot" 2>/dev/null || true
        break
    fi
done
