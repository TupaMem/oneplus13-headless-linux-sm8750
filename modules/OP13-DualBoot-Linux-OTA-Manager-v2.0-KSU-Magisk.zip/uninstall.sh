#!/system/bin/sh
for part in boot_b init_boot_b vendor_boot_b; do
    for path in "/dev/block/by-name/${part}" "/dev/block/bootdevice/by-name/${part}"; do
        if [ -b "$path" ]; then
            blockdev --setrw "$path" 2>/dev/null || true
        fi
    done
done
